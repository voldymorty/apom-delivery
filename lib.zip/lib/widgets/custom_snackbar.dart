import 'package:delivery/utils/colortheme.dart';
import 'package:flutter/material.dart';

/// Custom SnackBar for consistent look across the app
/// 
/// Usage examples:
/// CustomSnackBar.show(context, "Success message", isSuccess: true);
/// CustomSnackBar.show(context, "Error occurred", isError: true);
/// CustomSnackBar.show(context, "Info text", duration: const Duration(seconds: 4));
class CustomSnackBar {
  static void show(
    BuildContext context,
    String message, {
    bool isSuccess = false,
    bool isError = false,
    bool isInfo = false,
    Duration duration = const Duration(seconds: 3),
    SnackBarAction? action,
  }) {
    Color backgroundColor = AppColors.textSecondary; // default neutral
    IconData? icon;

    if (isSuccess) {
      backgroundColor = AppColors.success;
      icon = Icons.check_circle_outline_rounded;
    } else if (isError) {
      backgroundColor = AppColors.error;
      icon = Icons.error_outline_rounded;
    } else if (isInfo) {
      backgroundColor = AppColors.primaryGreen.withOpacity(0.9);
      icon = Icons.info_outline_rounded;
    }

    final snackBar = SnackBar(
      content: Row(
        children: [
          if (icon != null) ...[
            Icon(icon, color: Colors.white, size: 24),
            const SizedBox(width: 12),
          ],
          Expanded(
            child: Text(
              message,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 15,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
      backgroundColor: backgroundColor,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      margin: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 30,
      ),
      duration: duration,
      elevation: 6,
      action: action,
      dismissDirection: DismissDirection.horizontal,
    );

    ScaffoldMessenger.of(context).clearSnackBars(); // remove previous ones
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  // Quick success helper
  static void success(BuildContext context, String message, {Duration? duration}) {
    show(
      context,
      message,
      isSuccess: true,
      duration: duration ?? const Duration(seconds: 3),
    );
  }

  // Quick error helper
  static void error(BuildContext context, String message, {Duration? duration}) {
    show(
      context,
      message,
      isError: true,
      duration: duration ?? const Duration(seconds: 4),
    );
  }

  // Quick info helper
  static void info(BuildContext context, String message, {Duration? duration}) {
    show(
      context,
      message,
      isInfo: true,
      duration: duration ?? const Duration(seconds: 3),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:delivery/utils/colortheme.dart';

class CustomAppBar extends StatelessWidget {
  final Widget? leading;
  final String title;
  final String subtitle;
  final List<Widget>? actions;
  final bool centerTitle;
  final bool reverseTitleOrder;

  const CustomAppBar({
    super.key,
    this.leading,
    required this.title,
    required this.subtitle,
    this.actions,
    this.centerTitle = false,
    this.reverseTitleOrder = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Row(
        mainAxisAlignment:
            centerTitle ? MainAxisAlignment.center : MainAxisAlignment.start,
        children: [
          if (leading != null) ...[
            leading!,
            if (!centerTitle) const SizedBox(width: 12),
          ],
          if (centerTitle) const Spacer(),
          Column(
            crossAxisAlignment:
                centerTitle
                    ? CrossAxisAlignment.center
                    : CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children:
                reverseTitleOrder
                    ? [_buildSubtitle(), _buildTitle()]
                    : [_buildTitle(), _buildSubtitle()],
          ),
          if (centerTitle) const Spacer(),
          if (!centerTitle) const Spacer(),
          if (actions != null) ...actions!,
          if (centerTitle && leading != null)
            const SizedBox(width: 48), // Visual balance for leading icon
        ],
      ),
    );
  }

  Widget _buildTitle() {
    return Text(
      title,
      style: TextStyle(
        fontSize: centerTitle ? 14 : 22,
        fontWeight: FontWeight.w900,
        color: centerTitle ? Colors.blue : AppColors.textPrimary,
      ),
    );
  }

  Widget _buildSubtitle() {
    return Text(
      subtitle,
      style: TextStyle(
        fontSize: centerTitle ? 12 : 10,
        fontWeight: FontWeight.w800,
        color: AppColors.textSecondary,
        letterSpacing: 0.5,
      ),
    );
  }

  static Widget buildActionButton(IconData icon, {bool showDot = false}) {
    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Icon(icon, color: AppColors.textPrimary, size: 22),
          if (showDot)
            Positioned(
              top: 12,
              right: 12,
              child: Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: Colors.red,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 1.5),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

enum TaskType { pickup, drop, delivery }

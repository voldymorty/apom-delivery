import 'package:flutter/material.dart';
import 'package:delivery/widgets/custom_app_bar.dart';
import 'package:delivery/utils/colortheme.dart';
import 'package:delivery/Screens/pickup_details_screen.dart';
import 'package:delivery/Screens/delivery_details_screen.dart';
import 'package:delivery/widgets/pickup_card.dart';
import 'package:delivery/widgets/delivery_card.dart';
import 'package:delivery/utils/enums.dart';

class TaskScreen extends StatefulWidget {
  const TaskScreen({super.key});

  @override
  State<TaskScreen> createState() => _TaskScreenState();
}

class _TaskScreenState extends State<TaskScreen> {
  int _activeTab = 1;

  bool _shouldShowTask(TaskType type) {
    if (_activeTab == 1) return type == TaskType.pickup; // PICKUPS
    if (_activeTab == 2) {
      return type == TaskType.drop ||
          type == TaskType.delivery; // DROPS/DELIVERIES
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 20),
            CustomAppBar(
              title: 'Tasks',
              subtitle: 'VERIFICATION PROTOCOL',
              actions: [
                CustomAppBar.buildActionButton(Icons.history_sharp),
              ],
            ),
            const SizedBox(height: 10),

            // Tab Filters
            _buildFilterTabs(),
            const SizedBox(height: 24),

            // Search Protocol
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.03),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: TextField(
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                  decoration: InputDecoration(
                    hintText: 'SEARCH PROTOCOL',
                    hintStyle: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      color: AppColors.textSecondary.withOpacity(0.3),
                      letterSpacing: 1.2,
                    ),
                    prefixIcon: Icon(
                      Icons.search_rounded,
                      color: AppColors.textSecondary.withOpacity(0.4),
                      size: 20,
                    ),
                    suffixIcon: Icon(
                      Icons.qr_code_scanner_rounded,
                      color: AppColors.deliveryColor.withOpacity(0.8),
                      size: 20,
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Today's Schedule Header
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 16),
              child: Row(
                children: [
                  Text(
                    "TODAY'S SCHEDULE",
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      color: AppColors.textSecondary.withOpacity(0.4),
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(child: Divider(height: 1, thickness: 1)),
                ],
              ),
            ),

            // Task List
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                children: [
                  if (_shouldShowTask(TaskType.pickup))
                    PickupCard(
                      id: '8829',
                      status: 'Awaiting Verification',
                      statusColor: Colors.orange,
                      time: 'DUE 08:30 AM',
                      title: 'Green Valley Farms',
                      subtitle: 'Warehouse North Dock • Section B-12',
                      loadDetails: '40 Crates • Apples/Oranges',
                      weight: '~420 kg',
                      primaryActionLabel: 'View Details',
                      onPrimaryAction: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder:
                                (_) => const PickupDetailsScreen(taskId: '8821'),
                          ),
                        );
                      },
                    ),
                  
                  if (_shouldShowTask(TaskType.delivery))
                    DeliveryCard(
                      id: '9012',
                      status: 'At Warehouse',
                      statusColor: const Color(0xFF1B1B1B),
                      time: 'SCHEDULED 10:15 AM',
                      title: 'Fresh Mart Central',
                      subtitle: 'Customer Service Entrance',
                      loadDetails: '25 Crates • Leafy Greens',
                      priority: 'High',
                      primaryActionLabel: 'View Details',
                      onPrimaryAction: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder:
                                (_) => const DeliveryDetailsScreen(taskId: '9012'),
                          ),
                        );
                      },
                    ),

                  // Completed Summary Row
                  if (_activeTab == 0) ...[
                    _buildCompletedRow(),
                    const SizedBox(height: 30),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterTabs() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          _buildTabItem(1, 'PICKUPS', '08'),
          _buildTabItem(2, 'DROPS', '04'),
        ],
      ),
    );
  }

  Widget _buildTabItem(int index, String label, String count) {
    bool isActive = _activeTab == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _activeTab = index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: isActive ? AppColors.deliveryColor : Colors.transparent,
            borderRadius: BorderRadius.circular(16),
            boxShadow:
                isActive
                    ? [
                      BoxShadow(
                        color: AppColors.deliveryColor.withOpacity(0.3),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ]
                    : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  color: isActive ? Colors.white : AppColors.textSecondary,
                  letterSpacing: 0.5,
                ),
              ),
              
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCompletedRow() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.5),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black.withOpacity(0.03)),
      ),
      child: Row(
        children: [
          Icon(
            Icons.check_circle,
            color: AppColors.success.withOpacity(0.5),
            size: 24,
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '#8790 • Fresh Market Hub',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: AppColors.textPrimary.withOpacity(0.4),
                ),
              ),
              const Text(
                'DELIVERY VERIFIED',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  color: AppColors.success,
                ),
              ),
            ],
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.chevron_right_rounded,
              color: AppColors.textSecondary.withOpacity(0.3),
            ),
          ),
        ],
      ),
    );
  }
}

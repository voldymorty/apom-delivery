import 'package:delivery/widgets/custom_app_bar.dart';
import 'package:delivery/utils/colortheme.dart';
import 'package:flutter/material.dart';
import 'package:delivery/Screens/help_support_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            const CustomAppBar(
              
              title: 'My Profile',
              subtitle: 'ACCOUNT SETTINGS',
              
            ),
            const SizedBox(height: 40),
            const CircleAvatar(
              radius: 60,
              backgroundImage: NetworkImage('https://i.pravatar.cc/150?u=alex'),
            ),
            const SizedBox(height: 20),
            const Text(
              'Alex Rivera',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const Text(
              'OPS COMMANDER',
              style: TextStyle(color: AppColors.textSecondary),
            ),
            const SizedBox(height: 40),
            _buildProfileOption(
              Icons.person_outline_rounded,
              'Personal Details',
              onTap: () {},
            ),
            _buildProfileOption(
              Icons.history_rounded,
              'Task History',
              onTap: () {},
            ),
            _buildProfileOption(
              Icons.notifications_none_rounded,
              'Notification Preferences',
              onTap: () {},
            ),
            _buildProfileOption(
              Icons.help_outline_rounded,
              'Help & Support',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const HelpSupportDeliveryScreen(),
                  ),
                );
              },
            ),
            _buildProfileOption(
              Icons.logout_rounded,
              'Logout',
              isDestructive: true,
              onTap: () {},
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileOption(
    IconData icon,
    String title, {
    bool isDestructive = false,
    VoidCallback? onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: isDestructive ? Colors.red : AppColors.textPrimary,
            ),
            const SizedBox(width: 16),
            Text(
              title,
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: isDestructive ? Colors.red : AppColors.textPrimary,
              ),
            ),
            const Spacer(),
            Icon(
              Icons.chevron_right_rounded,
              color: AppColors.textSecondary.withOpacity(0.5),
            ),
          ],
        ),
        ),
      ),
    );
  }
}
